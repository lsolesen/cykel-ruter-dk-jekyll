var version = "1.5.1";
importScripts("https://cdn.subscribers.com/assets/subscribers-sw.js");
